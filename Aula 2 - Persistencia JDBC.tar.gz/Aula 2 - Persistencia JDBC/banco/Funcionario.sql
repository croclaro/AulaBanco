create database empresa;
use empresa;

create table funcionario(id int auto_increment, nome varchar(100), matricula varchar(100), anoNascimento int, salario double, primary key(id));

select * from funcionario;