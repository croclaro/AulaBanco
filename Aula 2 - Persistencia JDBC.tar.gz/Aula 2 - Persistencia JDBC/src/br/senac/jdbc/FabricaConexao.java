package br.senac.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.swing.JOptionPane;

public class FabricaConexao {

	public Connection getConexao(){
	
		try {
			return DriverManager.getConnection("jdbc:mysql://localhost/empresa?autoReconnect=false&useSSL=false", "root", "");
		} catch (SQLException evento) {
			JOptionPane.showMessageDialog(null, "Erro ao conectar ao banco de dados" +evento.getMessage());
			return null;
		}		
	}
}
