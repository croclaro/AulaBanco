package br.senac.jdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.swing.JOptionPane;

import br.senac.jdbc.FabricaConexao;
import br.senac.modelo.Funcionario;

public class FuncionarioDao {

	//ATRIBUTO DA CLASSE
	private Connection conexaoBD;
	
	//M�TODO CONSTRUTUTOR
	public FuncionarioDao() {
		
		conexaoBD = new FabricaConexao().getConexao();
	}
			
	public void adicionaBD(Funcionario funcionario){
		String comandoSQL = "insert into funcionario(nome, matricula, anoNascimento, salario) values(?,?,?,?)";
						
		try {
			PreparedStatement stmt = conexaoBD.prepareStatement(comandoSQL);
			stmt.setString(1, funcionario.getNome());
			stmt.setString(2, funcionario.getMatricula());
			stmt.setInt(3, funcionario.getAnoNascimento());
			stmt.setDouble(4, funcionario.getSalario());
			stmt.executeUpdate();
			stmt.close();
			JOptionPane.showMessageDialog(null, "Dados gravados com sucesso");
			
		} catch (SQLException evento) {
			JOptionPane.showMessageDialog(null, "Erro ao salvar os dados no banco" +evento.getMessage());
		}			
	}//FIM DO M�TODO ADICIONABD	
	
	public List<Funcionario> lerBD(){
		String comandoSQL = "select * from funcionario";
		
		try {
			List<Funcionario> listaFuncionario = new ArrayList<Funcionario>();
			PreparedStatement stmt = conexaoBD.prepareStatement(comandoSQL);
			ResultSet rs = stmt.executeQuery();
			
			while(rs.next()){
				Funcionario func = new Funcionario();
				func.setNome(rs.getString("nome"));
				func.setMatricula(rs.getString("matricula"));
				func.setAnoNascimento(rs.getInt("anoNascimento"));
				func.setSalario(rs.getDouble("salario"));				
				listaFuncionario.add(func);
			}
			rs.close();
			stmt.close();
			return listaFuncionario;
		} catch (SQLException evento) {
			JOptionPane.showMessageDialog(null, "Erro ao ler dados no banco" +evento.getMessage());
			
			return Collections.emptyList();
		}		
	}//FIM DO M�TODO LerDB
}
