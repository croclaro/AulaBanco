package br.senac.teste;

import java.util.List;

import br.senac.jdbc.dao.FuncionarioDao;
import br.senac.modelo.Funcionario;

public class TesteFuncionarioDao {

	public static void main(String[] args){
		
		FuncionarioDao funcDao = new FuncionarioDao();
		Funcionario func1 = new Funcionario();
		Funcionario func2 = new Funcionario();
		Funcionario func3 = new Funcionario();
		
		func1.setNome("Allan");
		func1.setMatricula("958658");
		func1.setAnoNascimento(2007);
		func1.setSalario(1200);
		
		func2.setNome("Jeanet");
		func2.setMatricula("654585");
		func2.setAnoNascimento(1900);
		func2.setSalario(6750);
		
		func3.setNome("Beatriz");
		func3.setMatricula("784585");
		func3.setAnoNascimento(1999);
		func3.setSalario(1500);
		
		funcDao.adicionaBD(func1);
		funcDao.adicionaBD(func2);
		funcDao.adicionaBD(func3);
		
		List<Funcionario> minhaLista = funcDao.lerBD();
		
		for(int i=0; i<minhaLista.size(); i++){
			System.out.println("Nome: " +minhaLista.get(i).getNome());
			System.out.println("Matricula: " +minhaLista.get(i).getMatricula());
			System.out.println("Ano Nascimento: " +minhaLista.get(i).getAnoNascimento());
			System.out.println("Salario: " +minhaLista.get(i).getSalario());
			System.out.println("-------------------------------------------");
		}
	}
}
