package br.cjdeveloper.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.swing.JOptionPane;

public class FabricaConexao {
     
	public Boolean teste;
	
	public Connection conexao(){
		
		try {
			return DriverManager.getConnection("jdbc:mysql://localhost/registro", "root", "C3lso1359");	    
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Erro ao conectar ao banco de dados" +e.getMessage());
			return null;
		}
	}	
}
