package br.cjdeveloper.jdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.swing.JOptionPane;

import br.cjdeveloper.modelo.Produto;

public class ProdutoDao {

	public Connection conexaoBD;
	
	//CONSTRUTOR
	public ProdutoDao(){
		
	}//FIM DO CONSTRUTOR
	
	public void adicionaBD(Produto produto){
		String comandoSQL = "Insert into Produto(nome, qtde, dataEntrada)" +"values(?,?,?)";
	
		try {
			PreparedStatement stmt = conexaoBD.prepareStatement(comandoSQL);
			stmt.setString(1,  produto.getNome());
			stmt.setInt(2, produto.getQtde());
			stmt.setString(3, produto.getDataEntrada());
			stmt.executeUpdate();
			stmt.close();
			JOptionPane.showMessageDialog(null, "Dados gravados com sucesso !!!");
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Erro ao gravar no banco de dados :(");
		}	
	}//FIM DO MÉTODO ADICONA BD
	
	public List<Produto> buscaTodosProdutos(){
		String comandoSQL = "select * from produto";
		
		try {
			List<Produto> produtoLista = new ArrayList<Produto>();
			PreparedStatement stmt = conexaoBD.prepareStatement(comandoSQL);
			ResultSet rs = stmt.executeQuery();
			
			while(rs.next()){
				Produto produto = new Produto();
				produto.setId_produto(rs.getInt("id_produto"));
				produto.setNome(rs.getString("nome"));
				produto.setQtde(rs.getInt("qtde"));
				produto.setDataEntrada(rs.getDate("dataEntrada"));
				produtoLista.add(produto);
			}
			rs.close();
			stmt.close();
			return produtoLista;
			
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Erro ao ler os dados :(" +e.getMessage());
			return Collections.emptyList();
		}
	}	
}
