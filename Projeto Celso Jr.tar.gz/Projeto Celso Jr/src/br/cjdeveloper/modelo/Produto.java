package br.cjdeveloper.modelo;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class Produto {
	
	//ATRIBUTOS DA CLASSE PRODUTO
	private int id_produto;
	private String nome;
	private int qtde;
	private Date dataEntrada;
	
	//METODOS GETTERS AND SETTERS ...
	public int getId_produto() {
		return id_produto;
	}
	public void setId_produto(int id_produto) {
		this.id_produto = id_produto;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public int getQtde() {
		return qtde;
	}
	public void setQtde(int qtde) {
		this.qtde = qtde;
	}
	public Date getDataEntrada() {
		return dataEntrada;
	}
	public void setDataEntrada(String dataEntrada) {
		SimpleDateFormat de = new SimpleDateFormat("dd,MM,yy");
		Date data = null;
		
		try {
			data = de.parse(dataEntrada);
		} catch (ParseException e) {
			e.printStackTrace();
		}		
		this.dataEntrada = data;
	}	
}
