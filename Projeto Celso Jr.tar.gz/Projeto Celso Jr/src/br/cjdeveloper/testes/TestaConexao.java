package br.cjdeveloper.testes;

import java.sql.Connection;

import br.cjdeveloper.jdbc.FabricaConexao;

public class TestaConexao {
	
	public static void main(String[] args) {
		
		Connection novaConexao = new FabricaConexao().conexao();
	}

}

