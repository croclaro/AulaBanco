package br.cjdeveloper.testes;

import br.cjdeveloper.modelo.Produto;

public class TesteClasses {

	public static void main(String[] args) {
		
		Produto produto1 = new Produto();
		
		produto1.setId_produto(1);
		produto1.setNome("Celso Jr");
		produto1.setQtde(100);
		produto1.setDataEntrada("02/12/2016");
		
		
	}
}
