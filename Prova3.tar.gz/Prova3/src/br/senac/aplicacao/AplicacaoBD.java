package br.senac.aplicacao;

import javax.swing.JOptionPane;

import br.senac.jdbc.dao.LivroDao;
import br.senac.modelo.Livro;

public class AplicacaoBD {

	public static void main(String[] args) {
		
		int resposta = JOptionPane.YES_OPTION;
		Livro novoLivro = new Livro();
		LivroDao livroBD = new LivroDao();
		
		while(resposta == JOptionPane.YES_OPTION){
			novoLivro.setIsbn(JOptionPane.showInputDialog("Digite o ISBN do Livro"));
			novoLivro.setTitulo(JOptionPane.showInputDialog("Digite o título do Livro"));
			novoLivro.setNumeroPaginas(JOptionPane.showInputDialog("Digite o número de páginas"));
			novoLivro.setAnoEdicao(JOptionPane.showInputDialog("Digite o ano de edição"));
			
			livroBD.inserirBD(novoLivro);
			resposta = JOptionPane.showConfirmDialog(null, "Deseja cadastrar outro livro?");
		}
		
		livroBD.lerDadosBD();
		livroBD.fecharBD();
	}
}
