package br.senac.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class FabricaConexao {

	public Connection getConexao(String banco, String usuario, String senha){
		
		try {
			return DriverManager.getConnection(banco, usuario, senha);
		} catch (SQLException evento) {
			System.out.println("Erro ao conectar no banco" +evento.getMessage());
			return null;
		}
	}
}
