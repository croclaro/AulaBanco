package br.senac.jdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import br.senac.jdbc.FabricaConexao;
import br.senac.modelo.Livro;

public class LivroDao {

	//ATRIBUTO DA CLASSE
	private Connection conexao;
	
	//CONSTRUTOR DA CLASSE AlunoDao
	public LivroDao(){
		conexao = new FabricaConexao().getConexao
				("jdbc:mysql://localhost/biblioteca?autoReconnect=false&useSSL=false", "root", "C3lso1359");
	}
	
	public void inserirBD(Livro novoLivro){
		String comandoSQL = "insert into tbLivro(isbn, titulo, numeroPaginas, anoEdicao) values(?,?,?,?)";
		
		try {
			PreparedStatement stmt = conexao.prepareStatement(comandoSQL);
			stmt.setString(1, novoLivro.getIsbn());
			stmt.setString(2, novoLivro.getTitulo());
			stmt.setInt(3, novoLivro.getNumeroPaginas());
			stmt.setInt(4, novoLivro.getAnoEdicao());			
			stmt.executeUpdate();
			stmt.close();
		} catch (SQLException evento) {
			System.out.println("Erro ao gravar no banco: " +evento.getMessage());
		}
	}
	
	public void lerDadosBD(){
		String comandoSQL = "select id_livro, isbn, titulo, numeroPaginas, anoEdicao from tbLivro";
		
		try {
			PreparedStatement stmt = conexao.prepareStatement(comandoSQL);
			ResultSet resultado = stmt.executeQuery();
			while(resultado.next()){
				int id            = resultado.getInt("id_livro");
				String isbn       = resultado.getString("isbn");
				String titulo     = resultado.getString("titulo");
				int numeroPaginas = resultado.getInt("numeroPaginas");
				int anoEdicao     = resultado.getInt("anoEdicao");
								
				System.out.println("Id do livro: " +id);
				System.out.println("Isbn: " +isbn);
				System.out.println("numeroPaginas: " +numeroPaginas);
				System.out.println("Ano edição: " +anoEdicao);
				System.out.println("------------------------");
			}
			resultado.close();
			
		} catch (SQLException evento) {
			System.out.println("N�o foi poss�vel acessar os dados: " +evento.getMessage());
		}
	}
	
	public void fecharBD(){
		try {
			conexao.close();
			System.out.println("Conex�o fechada com sucesso.");
		} catch (SQLException evento) {
			System.out.println("Erro ao tentar fechar a conex�o com o banco de dados: " +evento.getMessage());
		}
	}
}













