package br.senac.modelo;

public class Livro {

	private String isbn;
	private String titulo;
	private int numeroPaginas;
	private int anoEdicao;
	
	
	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public int getNumeroPaginas() {
		return numeroPaginas;
	}
	public void setNumeroPaginas(int numeroPaginas) {
		this.numeroPaginas = numeroPaginas;
	}
	public int getAnoEdicao() {
		return anoEdicao;
	}
	public void setAnoEdicao(int anoEdicao) {
		this.anoEdicao = anoEdicao;
	}
	public void setAnoEdicao(String showInputDialog) {
		// TODO Auto-generated method stub
		
	}
	public void setNumeroPaginas(String showInputDialog) {
		// TODO Auto-generated method stub
		
	}
	
	
	
	
}
